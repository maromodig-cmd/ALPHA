
import os
import sys
import time
import ctypes
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, simpledialog

import cv2
import face_recognition
from PIL import Image, ImageTk

APP_NAME = "ALPHA🛡"
LOCK_DELAY = 3.0

BASE_DIR = Path(__file__).resolve().parent
USERS_DIR = BASE_DIR / "users"
LOGO_PATH = BASE_DIR / "assets" / "alpha_logo.png"

class AlphaApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("900x650")
        self.root.minsize(760, 560)

        self.known_encodings = []
        self.known_names = []
        self.camera = None
        self.running = False
        self.away_since = None
        self.has_locked = False

        self.build_ui()
        self.load_users()

    def build_ui(self):
        top = tk.Frame(self.root, padx=16, pady=12)
        top.pack(fill="x")

        if LOGO_PATH.exists():
            logo = Image.open(LOGO_PATH).convert("RGB")
            logo.thumbnail((70, 70))
            self.logo_img = ImageTk.PhotoImage(logo)
            tk.Label(top, image=self.logo_img).pack(side="left", padx=(0, 12))

        title_box = tk.Frame(top)
        title_box.pack(side="left")
        tk.Label(title_box, text=APP_NAME, font=("Segoe UI", 22, "bold")).pack(anchor="w")
        tk.Label(title_box, text="Face ID Screen Protection", font=("Segoe UI", 10)).pack(anchor="w")

        self.status = tk.Label(
            self.root, text="جاهز", font=("Segoe UI", 14, "bold"), padx=12, pady=8
        )
        self.status.pack(fill="x", padx=16)

        self.video_label = tk.Label(self.root, text="الكاميرا متوقفة", font=("Segoe UI", 16))
        self.video_label.pack(expand=True, fill="both", padx=16, pady=12)

        controls = tk.Frame(self.root, pady=10)
        controls.pack(fill="x")

        tk.Button(controls, text="تشغيل الحماية", command=self.start,
                  font=("Segoe UI", 11, "bold"), padx=14, pady=8).pack(side="left", padx=5)
        tk.Button(controls, text="إيقاف", command=self.stop,
                  font=("Segoe UI", 11), padx=14, pady=8).pack(side="left", padx=5)
        tk.Button(controls, text="إضافة مستخدم", command=self.add_user,
                  font=("Segoe UI", 11), padx=14, pady=8).pack(side="right", padx=5)

        self.users_label = tk.Label(self.root, text="", anchor="w", padx=16, pady=8)
        self.users_label.pack(fill="x")

        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def load_users(self):
        self.known_encodings.clear()
        self.known_names.clear()

        for path in sorted(USERS_DIR.glob("*")):
            if path.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
                continue
            try:
                image = face_recognition.load_image_file(str(path))
                encs = face_recognition.face_encodings(image)
                if encs:
                    self.known_encodings.append(encs[0])
                    self.known_names.append(path.stem)
            except Exception as e:
                print("Could not load", path, e)

        self.users_label.config(
            text=f"المستخدمون المسجلون: {len(self.known_names)}"
            + ((" — " + ", ".join(self.known_names)) if self.known_names else "")
        )

    def add_user(self):
        name = simpledialog.askstring("ALPHA", "اكتب اسم المستخدم:")
        if not name:
            return

        safe_name = "".join(c for c in name if c.isalnum() or c in " _-").strip()
        if not safe_name:
            messagebox.showerror("ALPHA", "اسم غير صالح.")
            return

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            messagebox.showerror("ALPHA", "تعذر فتح الكاميرا.")
            return

        messagebox.showinfo("ALPHA", "اضغط Enter في نافذة الكاميرا لالتقاط صورة، أو Esc للإلغاء.")
        saved = False

        while True:
            ok, frame = cap.read()
            if not ok:
                break

            cv2.putText(frame, "Press ENTER to capture / ESC to cancel",
                        (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
            cv2.imshow("ALPHA - Register User", frame)
            key = cv2.waitKey(1) & 0xFF

            if key == 13:
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                encs = face_recognition.face_encodings(rgb)
                if not encs:
                    messagebox.showwarning("ALPHA", "لم يتم العثور على وجه واضح.")
                    continue
                out = USERS_DIR / f"{safe_name}.jpg"
                cv2.imwrite(str(out), frame)
                saved = True
                break
            elif key == 27:
                break

        cap.release()
        cv2.destroyAllWindows()

        if saved:
            self.load_users()
            messagebox.showinfo("ALPHA", f"تم تسجيل {safe_name} بنجاح.")

    def start(self):
        if not self.known_encodings:
            messagebox.showwarning("ALPHA", "أضف مستخدمًا مصرحًا به أولًا.")
            return

        if self.running:
            return

        self.camera = cv2.VideoCapture(0)
        if not self.camera.isOpened():
            messagebox.showerror("ALPHA", "تعذر فتح الكاميرا.")
            self.camera = None
            return

        self.running = True
        self.away_since = None
        self.has_locked = False
        self.status.config(text="الحماية تعمل", fg="green")
        self.update_frame()

    def update_frame(self):
        if not self.running or self.camera is None:
            return

        ok, frame = self.camera.read()
        if not ok:
            self.status.config(text="فشل التقاط الكاميرا", fg="red")
            self.stop()
            return

        # تصغير المعالجة لتحسين الأداء
        small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

        locations = face_recognition.face_locations(rgb, model="hog")
        encodings = face_recognition.face_encodings(rgb, locations)

        authorized = False

        for (top, right, bottom, left), enc in zip(locations, encodings):
            matches = face_recognition.compare_faces(
                self.known_encodings, enc, tolerance=0.55
            )

            name = "Unknown"
            if True in matches:
                idx = matches.index(True)
                name = self.known_names[idx]
                authorized = True

            top, right, bottom, left = [v * 2 for v in (top, right, bottom, left)]
            cv2.rectangle(frame, (left, top), (right, bottom), (255, 0, 0), 2)
            cv2.putText(frame, name, (left, max(25, top - 10)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255,255,255), 2)

        now = time.time()

        if authorized:
            self.away_since = None
            self.status.config(text="✓ المستخدم المصرح به موجود", fg="green")
        else:
            if self.away_since is None:
                self.away_since = now

            elapsed = now - self.away_since
            remaining = max(0, LOCK_DELAY - elapsed)

            if elapsed >= LOCK_DELAY:
                self.status.config(text="🔒 تم تأمين Windows", fg="red")
                if not self.has_locked:
                    self.has_locked = True
                    ctypes.windll.user32.LockWorkStation()
            else:
                self.status.config(
                    text=f"⚠ لا يوجد مستخدم مصرح — القفل خلال {remaining:.1f} ثانية",
                    fg="orange"
                )

        rgb_display = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        im = Image.fromarray(rgb_display)
        im.thumbnail((850, 470))
        tk_im = ImageTk.PhotoImage(im)
        self.video_label.config(image=tk_im, text="")
        self.video_label.image = tk_im

        self.root.after(30, self.update_frame)

    def stop(self):
        self.running = False
        if self.camera is not None:
            self.camera.release()
            self.camera = None
        self.video_label.config(image="", text="الكاميرا متوقفة")
        self.video_label.image = None
        self.status.config(text="متوقف", fg="gray")

    def close(self):
        self.stop()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = AlphaApp(root)
    root.mainloop()
