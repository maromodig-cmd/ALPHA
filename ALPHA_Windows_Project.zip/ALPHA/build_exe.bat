@echo off
setlocal
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install pyinstaller
pyinstaller --noconfirm --clean --onefile --windowed --name "ALPHA" --icon "assets\alpha.ico" --add-data "assets;assets" --add-data "users;users" main.py
echo.
echo Build complete: dist\ALPHA.exe
pause
