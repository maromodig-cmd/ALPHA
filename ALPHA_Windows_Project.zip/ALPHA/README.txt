# ALPHA🛡 — Windows

1. Install Python 3.10/3.11 (64-bit).
2. Open CMD in this folder.
3. Run `pip install -r requirements.txt`.
4. Run `python main.py`.
5. Use "إضافة مستخدم" to register an authorized face.
6. Use "تشغيل الحماية".
7. To create EXE, run `build_exe.bat`.

The EXE is created in `dist\ALPHA.exe`.

Note: face_recognition/dlib installation can vary by Python version. If installation fails, use a supported Python version and a matching prebuilt dlib package.
